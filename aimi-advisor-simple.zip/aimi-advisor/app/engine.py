"""
Rule-based recommendations engine with AIMI code logic baked in.

Encodes the safety/threshold logic observed in the OpenAPS AIMI source:
  - HypoThresholdMath: LGS is a hard floor; must be set sensibly
  - PkpdPresetProfiles: Ultra-fast preset bounds (DIA 5-8h, peak 35-95, init DIA 6.0)
  - PkpdSmbTailDamping: cautious=0.92, neutral=0.85, permissive=0.70
  - PkpdCorrectionPrudence: ISF fusion neutral=(0.75,1.25), prudent=(0.85,1.10)
  - InsulinStackingStance: Max IOB ceiling; priority factor 1.20 + 2.0U extra
  - PkpdLearningPace: slow=0.2h/2min, normal=0.5h/5min, fast=1.0h/10min

All glucose values handled in mmol/L for the user (units in profile).
Each recommendation includes: id, severity, title, detail, current, recommended,
and the code reference that justifies it.
"""

MMOL = 18.018

SEV_CRITICAL = "critical"
SEV_WARN = "warn"
SEV_OK = "ok"
SEV_INFO = "info"

# Ultra-fast preset values from PkpdPresetProfiles.kt
ULTRAFAST = {
    "dia_min": 5.0, "dia_max": 8.0, "peak_min": 35.0, "peak_max": 95.0,
    "init_dia": 6.0, "init_peak": 55.0, "anchor_dia": 4.0, "anchor_peak": 55.0,
    "isf_min": 0.75, "isf_max": 1.25, "tail_damping": 0.85,
    "max_dia_change": 0.5, "max_peak_change": 5.0,
}


def _rec(rid, sev, title, detail, current=None, recommended=None, code_ref=None):
    return {
        "id": rid, "severity": sev, "title": title, "detail": detail,
        "current": current, "recommended": recommended, "code_ref": code_ref,
    }


def generate(analysis: dict, profile: dict, settings: dict, actual_tdd_est=None) -> dict:
    """
    analysis: output of analytics.analyze_entries
    profile: output of analytics.extract_profile (units, isf, cr, basal_tdd, ...)
    settings: dict of AIMI settings the user entered (may be partial)
    Returns dict with recommendations[], score, summary.
    """
    recs = []
    tir = analysis.get("tir", {})
    in_range = tir.get("in_range", 0)
    low = tir.get("low", 0) + tir.get("very_low", 0)
    very_low = tir.get("very_low", 0)
    high = tir.get("high", 0) + tir.get("very_high", 0)
    cv = analysis.get("cv", 0)
    hourly = analysis.get("hourly", [])
    low_per_day = analysis.get("low_events_per_day", 0)

    s = settings or {}

    # ---- 1. LGS THRESHOLD (HypoThresholdMath.kt: hard floor override) ----
    lgs = s.get("lgs_threshold")
    if lgs is not None:
        lgs = float(lgs)
        if lgs > 5.0:
            recs.append(_rec(
                "lgs", SEV_CRITICAL,
                "Lower LGS Threshold — Immediate Safety Fix",
                f"At {lgs} mmol/L, insulin suspends while BG is still normal. "
                "HypoThresholdMath.computeHypoThreshold uses this as a hard floor that "
                "overrides the formula-based threshold, driving suspend→rise→overcorrect→low cycles.",
                f"{lgs} mmol/L", "4.0–4.2 mmol/L",
                "HypoThresholdMath.kt → computeHypoThreshold()",
            ))
        elif lgs > 4.4:
            recs.append(_rec(
                "lgs", SEV_WARN, "Consider lowering LGS slightly",
                f"LGS at {lgs} is on the higher side; 4.0–4.2 gives protection without premature suspends.",
                f"{lgs} mmol/L", "4.0–4.2 mmol/L",
                "HypoThresholdMath.kt",
            ))

    # ---- 2. MAX IOB (InsulinStackingStance + priority factor) ----
    max_iob = s.get("max_iob")
    tdd = actual_tdd_est or profile.get("basal_tdd")
    if max_iob is not None:
        max_iob = float(max_iob)
        # effective ceiling = max_iob * 1.20 + 2.0 (priority factors)
        eff = max_iob * 1.20 + 2.0
        # sensible ceiling ~ 0.15 * TDD if known, else heuristic
        target = round(0.15 * tdd, 1) if tdd else 6.5
        target = max(4.0, min(target, 8.0))
        if max_iob > target * 1.4:
            recs.append(_rec(
                "max_iob", SEV_CRITICAL,
                "Reduce Max IOB — Prevent Insulin Stacking",
                f"Max IOB {max_iob}U with priority factors gives an effective ceiling of "
                f"{eff:.1f}U (1.20× + 2.0U extra). "
                f"{'With TDD ~' + str(round(tdd)) + 'U/day, ' if tdd else ''}"
                "this allows excessive stacking. InsulinStackingStance.evaluate() is the brake.",
                f"{max_iob} U", f"{target} U",
                "InsulinStackingStance.kt + OApsAIMIPriorityMaxIobFactor",
            ))
        elif max_iob > target * 1.15:
            recs.append(_rec(
                "max_iob", SEV_WARN, "Max IOB slightly high",
                f"Consider lowering toward {target}U to tighten the stacking brake.",
                f"{max_iob} U", f"{target} U",
                "InsulinStackingStance.kt",
            ))

    # ---- 3. PK/PD INITIAL DIA (PkpdPresetProfiles ULTRA_FAST) ----
    init_dia = s.get("pkpd_initial_dia")
    insulin = (s.get("insulin_type") or "ultrafast").lower()
    if init_dia is not None and "ultra" in insulin:
        init_dia = float(init_dia)
        if abs(init_dia - ULTRAFAST["init_dia"]) > 0.3:
            recs.append(_rec(
                "init_dia", SEV_WARN,
                "Align PK/PD Initial DIA with Ultra-fast preset",
                f"Initial DIA {init_dia}h doesn't match the Ultra-fast preset (6.0h). "
                "Mismatch resets the learner's starting point on each restart. "
                "Use 'Run setup guide again' on the Simple tab to fix in one step.",
                f"{init_dia} h", "6.0 h",
                "PkpdPresetProfiles.kt → applyPkpdInsulinPreset(ULTRA_FAST)",
            ))

    # ---- 4. TDD7 calibration ----
    tdd7 = s.get("tdd7")
    if tdd7 is not None and tdd:
        tdd7 = float(tdd7)
        if tdd7 < tdd * 0.85:
            recs.append(_rec(
                "tdd7", SEV_WARN,
                "Raise TDD7 to better calibrate ISF",
                f"TDD7 is {tdd7}U but actual usage is ~{round(tdd)}U/day. "
                "ci = 450/TDD7 drives the carb limit and ISF anchor; underestimating TDD "
                "produces a looser ISF than reality requires.",
                f"{tdd7} U", f"{round(tdd)} U",
                "DetermineBasalAIMI2.kt line ~2794 (ci = 450/tdd7Days)",
            ))

    # ---- 5. ISF FUSION (PkpdCorrectionPrudence neutral = 0.75/1.25) ----
    isf_min = s.get("isf_fusion_min")
    isf_max = s.get("isf_fusion_max")
    if isf_max is not None:
        isf_max = float(isf_max)
        if isf_max < 1.23 and high > 15:
            recs.append(_rec(
                "isf_fusion", SEV_WARN,
                "Restore ISF Fusion toward neutral",
                f"ISF fusion max factor {isf_max} caps how aggressively AIMI tightens ISF "
                f"during rises. With {high:.0f}% time high, the ceiling is likely being hit. "
                "IsfFusion.fused() uses maxSafeIsf = tdd × maxFactor × 1.5.",
                f"min {isf_min} / max {isf_max}", "0.75 / 1.25",
                "PkpdCorrectionPrudence.kt (neutral = 0.75/1.25)",
            ))

    # ---- 6. SENSITIVITY RAISES TARGET (asymmetry check) ----
    srt = s.get("sensitivity_raises_target")
    rlt = s.get("resistance_lowers_target")
    if srt is False and rlt is True and low > 3:
        recs.append(_rec(
            "sens_target", SEV_WARN,
            "Enable 'Sensitivity raises target'",
            "You have resistance-lowers-target ON but sensitivity-raises-target OFF — "
            "a one-way ratchet. During sensitive periods the target never rises to protect you. "
            "Both flags are checked independently in the code.",
            "OFF", "ON",
            "DetermineBasalAIMI2.kt line ~2571",
        ))

    # ---- 7. LEARNING PACE (PkpdLearningPace) ----
    pace = s.get("learning_pace")
    if pace and pace.lower() == "slow":
        recs.append(_rec(
            "learning_pace", SEV_OK,
            "Consider switching learning speed to Normal",
            "Slow = 0.2h DIA / 2min peak change per day. Once the learner has converged, "
            "Normal (0.5h / 5min) adapts faster to site changes and daily variation.",
            "SLOW", "NORMAL",
            "PkpdSettingsSupport.kt → PkpdLearningPace",
        ))

    # ---- 8. SMB TAIL DAMPING (PkpdSmbTailDamping) ----
    tail = s.get("smb_tail_damping")
    if tail is not None:
        tail = float(tail)
        if low_per_day > 2 and tail < 0.90:
            recs.append(_rec(
                "tail_damping", SEV_OK,
                "Slightly increase SMB tail damping while lows are frequent",
                f"Tail damping {tail} sits between neutral (0.85) and cautious (0.92). "
                f"With {low_per_day} low episodes/day, nudging toward 0.90 dampens late-tail SMBs.",
                f"{tail}", "0.90–0.92",
                "PkpdSmbTailDamping.kt (cautious=0.92)",
            ))

    # ---- 9. OVERNIGHT PATTERN (data-driven) ----
    night = [h for h in hourly if h.get("hour") in (2, 3, 4, 5, 6) and h.get("mean_mmol")]
    if night:
        night_avg = sum(h["mean_mmol"] for h in night) / len(night)
        night_min = min(h.get("min_mmol", 99) for h in night)
        if night_min < 3.0 or night_avg < 5.5:
            recs.append(_rec(
                "overnight", SEV_WARN,
                "Overnight lows detected (2–6am)",
                f"Overnight average is {night_avg:.1f} mmol/L with lows down to {night_min} mmol/L. "
                "Combined with the LGS fix, review whether overnight basal carries too much, "
                "or evening IOB stacks into the night.",
                f"avg {night_avg:.1f} / min {night_min}", "target avg ~6.0",
                "data-driven (hourly pattern)",
            ))

    # ---- 10. EVENING HIGHS (data-driven) ----
    evening = [h for h in hourly if h.get("hour") in (17, 18, 19, 20) and h.get("mean_mmol")]
    if evening:
        eve_avg = sum(h["mean_mmol"] for h in evening) / len(evening)
        if eve_avg > 8.0:
            recs.append(_rec(
                "evening", SEV_INFO,
                "Evening highs detected (5–8pm)",
                f"Evening average is {eve_avg:.1f} mmol/L. This may reflect dinner coverage "
                "or an ISF fusion ceiling limiting corrections. Review CR/meal handling.",
                f"avg {eve_avg:.1f}", "target avg ~7.0",
                "data-driven (hourly pattern)",
            ))

    score = _score(in_range, low, very_low, cv, low_per_day, recs)
    summary = _summary(in_range, low, cv, recs)

    return {
        "recommendations": recs,
        "score": score,
        "summary": summary,
        "counts": {
            "critical": sum(1 for r in recs if r["severity"] == SEV_CRITICAL),
            "warn": sum(1 for r in recs if r["severity"] == SEV_WARN),
            "ok": sum(1 for r in recs if r["severity"] in (SEV_OK, SEV_INFO)),
        },
    }


def _score(in_range, low, very_low, cv, low_per_day, recs):
    score = 100
    # TIR component
    if in_range < 70:
        score -= (70 - in_range) * 0.8
    # Lows
    if low > 4:
        score -= (low - 4) * 3
    if very_low > 1:
        score -= (very_low - 1) * 6
    # Variability
    if cv > 36:
        score -= (cv - 36) * 1.5
    # Episodes
    if low_per_day > 1:
        score -= (low_per_day - 1) * 3
    # Critical recs
    score -= sum(4 for r in recs if r["severity"] == SEV_CRITICAL)
    return max(0, min(100, round(score)))


def _summary(in_range, low, cv, recs):
    crit = sum(1 for r in recs if r["severity"] == SEV_CRITICAL)
    parts = []
    if in_range >= 70:
        parts.append(f"Time-in-range of {in_range}% is above the 70% clinical target.")
    else:
        parts.append(f"Time-in-range of {in_range}% is below the 70% target.")
    if low > 4:
        parts.append(f"Time below range ({low}%) exceeds the 4% safety limit.")
    if cv > 36:
        parts.append(f"Variability (CV {cv}%) is above the recommended 36%.")
    if crit:
        parts.append(f"{crit} critical safety issue(s) need attention.")
    if not crit and in_range >= 70 and low <= 4:
        parts.append("Control is solid with no critical safety gaps.")
    return " ".join(parts)
